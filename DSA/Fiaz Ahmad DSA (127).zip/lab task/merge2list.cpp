#include <iostream>
using namespace std;
 class node{
 	public:
 	int data;
 	node * next;
 	
 	node(int val){
 		data=val;
 		next=NULL;
	 }
 };
 
 class List{
 	public:
 		node*head;
 		node*tail;
 		
 		List(){
 			head=tail=NULL;
		 }
	void insertatstart(int val){
		node*newnode=new node(val);
		if(head==NULL){
			head=tail=newnode;
		}
		else{
			newnode->next=head;
			head=newnode;	
		}
	
	}
void mergelist(node* h1,node * t1,node* h2,node* t2){
  if(h1==NULL){
    	head=h2;
    	tail=t2;
    	return ;
	}
	if(h2==NULL){
		head=h1;
		tail=t1;
		return;
	}
	t1->next=h2;
	head=h1;
	tail=t2;
	}

	void display(){
		node*temp=head;
		while(temp!=NULL){
			cout<<temp->data;
			temp=temp->next;
			
			
		}
		cout<<endl;
	}
	
 };
 int main(){
 	List l1;
 	l1.insertatstart(5);
 	l1.insertatstart(6);
 	l1.insertatstart(8);
 	l1.insertatstart(9);
 
 	l1.display();
 	List l2;
 	l2.insertatstart(6);
 	l2.insertatstart(2);
 	l2.display();
 	
 	List l3;
 	l3.mergelist(l1.head,l1.tail,l2.head,l2.tail);
 	l3.display();
 	return 0;
 	
 }

