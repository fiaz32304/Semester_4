#include <iostream>
using namespace std;
 class node{
 	public:
 	int data;
 	node * next;
 	
 	node(int val){
 		data=val;
 		next=NULL;
	 }
 };
 
 class List{
 	public:
 		node*head;
 		node*tail;
 		
 		List(){
 			head=tail=NULL;
		 }
	void insertatstart(int val){
		node*newnode=new node(val);
		if(head==NULL){
			head=tail=newnode;
		}
		else{
			newnode->next=head;
			head=newnode;	
		}
	
	}
	void reverse(){
		node*prev=NULL;
		node* current=head;
		node*temp;
		
		while(current!=NULL){
			temp=current->next;
			current->next=prev;
			prev=current;
			current=temp;
			
		}
		head=prev;
		
	}
	void display(){
		node*temp=head;
		while(temp!=NULL){
			cout<<temp->data;
			temp=temp->next;
			
			
		}
		cout<<endl;
	}
	
 };
 int main(){
 	List ll;
 	ll.insertatstart(5);
 	ll.insertatstart(6);
 	ll.insertatstart(8);
 	ll.insertatstart(9);
 	ll.display();
 	ll.reverse();
 	ll.display();
 	
 	return 0;
 	
 }
