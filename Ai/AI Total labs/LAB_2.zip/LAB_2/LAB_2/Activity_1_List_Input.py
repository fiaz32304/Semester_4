# Activity 1: Accept 5 values from user and store in a list, then display all

my_list = []

for i in range(5):
    value = input("Enter value " + str(i + 1) + ": ")
    my_list.append(value)

print("\nList values:")
for item in my_list:
    print(item)
