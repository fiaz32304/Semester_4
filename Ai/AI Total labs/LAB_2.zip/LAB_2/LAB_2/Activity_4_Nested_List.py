# Activity 4: Nesting a list inside a list and accessing elements

# Creating a List with multiple values
List = ["Geeks", "For", "Geeks"]
print("\nList containing multiple values: ")
print(List)

# Creating a Multi-Dimensional List
List2 = [['Geeks', 'For'], ['Geeks']]
print("\nMulti-Dimensional List: ")
print(List2)

# Accessing element using index number
print("Accessing element from the list")
print(List[0])
print(List[2])

# Accessing element using negative indexing
print("Accessing element using negative indexing")

# print the last element of list
print(List[-1])

# print the third last element of list
print(List[-3])
