# Lab Task 1: Python Class Exercises

import tracemalloc
from sys import getsizeof

print("=" * 50)
print("i. Instance namespace display")
print("=" * 50)

class Sample:
    def __init__(self, x, y):
        self.x = x
        self.y = y

obj = Sample(10, 20)
print("Namespace of instance:", obj.__dict__)


print("\n" + "=" * 50)
print("ii. student_data() function")
print("=" * 50)

def student_data(student_id, student_name=None, student_class=None):
    print("Student ID:", student_id)
    if student_name:
        print("Student Name:", student_name)
    if student_class:
        print("Student Class:", student_class)

student_data(101)
student_data(102, student_name="Ali")
student_data(103, student_name="Sara", student_class="10-A")


print("\n" + "=" * 50)
print("iii. Student class type and __dict__ keys")
print("=" * 50)

class Student:
    student_name = "Akber"
    marks = 95

print("Type of Student class:", type(Student))
print("__dict__ keys:", list(Student.__dict__.keys()))
print("__module__ attribute:", Student.__module__)


print("\n" + "=" * 50)
print("iv. Empty classes and isinstance / issubclass checks")
print("=" * 50)

class Student2:
    pass

class Marks:
    pass

s = Student2()
m = Marks()

print("s is instance of Student2:", isinstance(s, Student2))
print("m is instance of Marks:", isinstance(m, Marks))
print("s is instance of Marks:", isinstance(s, Marks))
print("Student2 is subclass of object:", issubclass(Student2, object))
print("Marks is subclass of object:", issubclass(Marks, object))


print("\n" + "=" * 50)
print("v. Modify attribute values")
print("=" * 50)

class Student3:
    student_name = "Akber"
    marks = 90

print("Original - Name:", Student3.student_name, "| Marks:", Student3.marks)
Student3.student_name = "Ali"
Student3.marks = 95
print("Modified - Name:", Student3.student_name, "| Marks:", Student3.marks)


print("\n" + "=" * 50)
print("vi. Add and remove attributes")
print("=" * 50)

class Student4:
    student_id = 101
    student_name = "Akber"

Student4.student_class = "10-A"
print("All attributes:", Student4.__dict__)

delattr(Student4, 'student_name')
print("After removing student_name:", Student4.__dict__)


print("\n" + "=" * 50)
print("vii. Display attributes using a function")
print("=" * 50)

class Student5:
    student_id = 201
    student_name = "Sara"
    student_class = "11-B"

    def display(self):
        print("student_id   :", self.student_id)
        print("student_name :", self.student_name)
        print("student_class:", self.student_class)

s5 = Student5()
s5.display()


print("\n" + "=" * 50)
print("viii. Two instances with different values")
print("=" * 50)

class Student6:
    def __init__(self, student_id, student_name, marks):
        self.student_id = student_id
        self.student_name = student_name
        self.marks = marks

student1 = Student6(1, "Akber", 90)
student2 = Student6(2, "Sara", 85)

print("student1 -> id:", student1.student_id,
      "| name:", student1.student_name,
      "| marks:", student1.marks)
print("student2 -> id:", student2.student_id,
      "| name:", student2.student_name,
      "| marks:", student2.marks)


print("\n" + "=" * 50)
print("ix. Memory allocation test on class")
print("=" * 50)

def create_students():
    students = []
    for i in range(10000):
        students.append(Student6(i, "Student" + str(i), i * 2))
    return students

tracemalloc.start()
result = create_students()
mem = tracemalloc.get_traced_memory()
print("Memory (current, peak):", mem)
tracemalloc.stop()


print("\n" + "=" * 50)
print("x. Reducing memory using __slots__")
print("=" * 50)

class StudentSlots:
    __slots__ = ['student_id', 'student_name', 'marks']

    def __init__(self, student_id, student_name, marks):
        self.student_id = student_id
        self.student_name = student_name
        self.marks = marks

tracemalloc.start()
students_slots = []
for i in range(10000):
    students_slots.append(StudentSlots(i, "Student" + str(i), i * 2))

mem_slots = tracemalloc.get_traced_memory()
print("Memory with __slots__ (current, peak):", mem_slots)
tracemalloc.stop()

print("\n__slots__ reduces memory by removing per-instance __dict__")
print("Regular instance size :", getsizeof(result[0].__dict__), "bytes (dict overhead)")
print("Slots instance has no __dict__ — more memory efficient")
