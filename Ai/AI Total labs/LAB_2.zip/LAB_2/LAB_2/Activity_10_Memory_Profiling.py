# Activity 10: Memory allocation monitoring using tracemalloc

import tracemalloc

# Function to monitor
def app():
    lt = []
    for i in range(0, 100000):
        lt.append(i)

# Start monitoring
tracemalloc.start()

# Function call
app()

# Display memory usage (current, peak)
memory = tracemalloc.get_traced_memory()
print("Memory usage (current, peak):", memory)
print(f"Current: {memory[0]} bytes")
print(f"Peak:    {memory[1]} bytes")

# Stop monitoring
tracemalloc.stop()
