# Activity 9: Classes in Python

class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def myfunc(self):
        print("Hello my name is " + self.name)
        print("Hello my age is " + str(self.age))

p1 = Person("Akber", 36)
p1.myfunc()
