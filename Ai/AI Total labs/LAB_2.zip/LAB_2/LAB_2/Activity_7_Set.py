# Activity 7: Sets in Python

# Creating a Set with mixed type values
Set = set([1, 2, 'Geeks', 4, 'For', 6, 'Geeks'])
print("\nSet with the use of Mixed Values")
print(Set)

# Accessing elements using for loop
print("\nElements of set: ")
for i in Set:
    print(i, end=" ")
print()

# Checking element using 'in' keyword
print("Geeks" in Set)

# ── Frozen Set ──
print("\n--- Frozen Set ---")
frozen = frozenset([1, 2, 3, 4, 5, 5, 4])
print("Frozen Set:", frozen)

# Frozen sets are immutable — this would raise an error:
try:
    frozen.add(6)
except AttributeError as e:
    print("Cannot modify frozenset:", e)
