# Activity 5: Dictionaries in Python

# Creating a Dictionary
Dict = {'Name': 'Geeks', 1: [1, 2, 3, 4]}
print("Creating Dictionary: ")
print(Dict)

# Accessing element using key
print("Accessing a element using key:")
print(Dict['Name'])

# Accessing element using get() method
print("Accessing a element using get:")
print(Dict.get(1))

# Dictionary comprehension
myDict = {x: x**2 for x in [1, 2, 3, 4, 5]}
print(myDict)

# ── OrderedDict ──
print("\n--- OrderedDict ---")
from collections import OrderedDict

print("Before deleting:\n")
od = OrderedDict()
od['a'] = 1
od['b'] = 2
od['c'] = 3
od['d'] = 4
for key, value in od.items():
    print(key, value)

print("\nAfter deleting:\n")
od.pop('c')
for key, value in od.items():
    print(key, value)

print("\nAfter re-inserting:\n")
od['c'] = 3
for key, value in od.items():
    print(key, value)

# ── ChainMap ──
print("\n--- ChainMap ---")
from collections import ChainMap

d1 = {'a': 1, 'b': 2}
d2 = {'c': 3, 'd': 4}
d3 = {'e': 5, 'f': 6}

c = ChainMap(d1, d2, d3)
print(c)
print(c['a'])

# Accessing missing key will raise KeyError
try:
    print(c['g'])
except KeyError as e:
    print("KeyError:", e)
