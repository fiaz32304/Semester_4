# Activity 8: Python Strings

String = "Welcome to GeeksForGeeks"
print("Creating String: ")
print(String)

# Printing First character
print("\nFirst character of String is: ")
print(String[0])

# Printing Last character
print("\nLast character of String is: ")
print(String[-1])

# ── Bytearray experiment ──
print("\n--- Bytearray ---")
ba = bytearray("Hello", "utf-8")
print("Bytearray:", ba)

# Modifying bytearray (mutable unlike string)
ba[0] = ord('J')
print("Modified Bytearray:", ba)
print("Decoded:", ba.decode("utf-8"))
