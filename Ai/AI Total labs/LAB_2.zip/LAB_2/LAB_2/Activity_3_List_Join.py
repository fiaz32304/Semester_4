# Activity 3: Accept two lists from user and display their join

list1 = []
list2 = []

n1 = int(input("How many elements in list 1? "))
for i in range(n1):
    val = input("Enter value " + str(i + 1) + " for list 1: ")
    list1.append(val)

n2 = int(input("How many elements in list 2? "))
for i in range(n2):
    val = input("Enter value " + str(i + 1) + " for list 2: ")
    list2.append(val)

joined_list = list1 + list2

print("\nList 1:", list1)
print("List 2:", list2)
print("Joined List:", joined_list)
