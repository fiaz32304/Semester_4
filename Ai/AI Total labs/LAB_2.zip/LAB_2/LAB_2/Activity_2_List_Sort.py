# Activity 2: Accept 5 integers, store in list, display in ascending order

my_list = []

for i in range(5):
    num = int(input("Enter integer " + str(i + 1) + ": "))
    my_list.append(num)

my_list.sort()

print("\nList in ascending order:")
print(my_list)
