# Activity 6: Tuples in Python

# Creating a Tuple with Strings
Tuple = ('Geeks', 'For')
print("\nTuple with the use of String: ")
print(Tuple)

# Creating a Tuple from a list
list1 = [1, 2, 4, 5, 6]
print("\nTuple using List: ")
Tuple = tuple(list1)

# Accessing element using indexing
print("First element of tuple")
print(Tuple[0])

# Accessing element from last using negative indexing
print("\nLast element of tuple")
print(Tuple[-1])

print("\nThird last element of tuple")
print(Tuple[-3])

# ── NamedTuple ──
print("\n--- NamedTuple ---")
from collections import namedtuple

# Declaring namedtuple
Student = namedtuple('Student', ['name', 'age', 'DOB'])

# Adding values
S = Student('Akber', '19', '2541997')

# Access using index
print("The Student age using index is : ", end="")
print(S[1])

# Access using name
print("The Student name using keyname is : ", end="")
print(S.name)
