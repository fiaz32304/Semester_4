# Lab Task 2: BFS on Romania Map — Arad to Bucharest
# Based on the classic AI Travelling Salesman Problem map
# Save as: BFS_REG#.py (rename with your registration number)

# Romania road map with distances (km)
romania_graph = {
    'Arad':         [('Zerind', 75),    ('Sibiu', 140),   ('Timisoara', 118)],
    'Zerind':       [('Arad', 75),      ('Oradea', 71)],
    'Oradea':       [('Zerind', 71),    ('Sibiu', 151)],
    'Sibiu':        [('Arad', 140),     ('Oradea', 151),  ('Fagaras', 99),   ('Rimnicu', 80)],
    'Timisoara':    [('Arad', 118),     ('Lugoj', 111)],
    'Lugoj':        [('Timisoara', 111),('Mehadia', 70)],
    'Mehadia':      [('Lugoj', 70),     ('Drobeta', 75)],
    'Drobeta':      [('Mehadia', 75),   ('Craiova', 120)],
    'Craiova':      [('Drobeta', 120),  ('Rimnicu', 146), ('Pitesti', 138)],
    'Rimnicu':      [('Sibiu', 80),     ('Craiova', 146), ('Pitesti', 97)],
    'Fagaras':      [('Sibiu', 99),     ('Bucharest', 211)],
    'Pitesti':      [('Rimnicu', 97),   ('Craiova', 138), ('Bucharest', 101)],
    'Bucharest':    [('Fagaras', 211),  ('Pitesti', 101), ('Giurgiu', 90),   ('Urziceni', 85)],
    'Giurgiu':      [('Bucharest', 90)],
    'Urziceni':     [('Bucharest', 85), ('Hirsova', 98),  ('Vaslui', 142)],
    'Hirsova':      [('Urziceni', 98),  ('Eforie', 86)],
    'Eforie':       [('Hirsova', 86)],
    'Vaslui':       [('Urziceni', 142), ('Iasi', 92)],
    'Iasi':         [('Vaslui', 92),    ('Neamt', 87)],
    'Neamt':        [('Iasi', 87)]
}

def bfs_romania(graph, start, goal):
    """
    BFS on Romania map.
    Finds path with fewest stops (not necessarily lowest cost).
    Also calculates total distance of that path.
    """
    visited = set()
    # Queue: (current_node, path_list, total_distance)
    queue = [(start, [start], 0)]

    print("\n" + "=" * 55)
    print("BFS Romania Map")
    print("Start : {}".format(start))
    print("Goal  : {}".format(goal))
    print("=" * 55)

    while queue:
        node, path, distance = queue.pop(0)

        if node == goal:
            print("\nPath found:")
            print("  " + " -> ".join(path))
            print("\nTotal distance : {} km".format(distance))
            print("Stops          : {}".format(len(path) - 1))
            return path, distance

        if node not in visited:
            visited.add(node)
            for neighbour, cost in graph[node]:
                if neighbour not in visited:
                    queue.append((
                        neighbour,
                        path + [neighbour],
                        distance + cost
                    ))

    print("No path found from '{}' to '{}'.".format(start, goal))
    return None, None

# i. + ii. Arad to Bucharest
bfs_romania(romania_graph, 'Arad', 'Bucharest')

# Additional variations
bfs_romania(romania_graph, 'Timisoara', 'Bucharest')
bfs_romania(romania_graph, 'Oradea', 'Bucharest')
bfs_romania(romania_graph, 'Arad', 'Eforie')
