# Activity 3: BFS on a different graph (Lab 04 graph)
# Graph structure based on the figure described in Activity 3
# Nodes: A, B, C, D, E, F, G with connections as per the figure

graph = {
    'A': ['B', 'C'],
    'B': ['A', 'D', 'E'],
    'C': ['A', 'F'],
    'D': ['B'],
    'E': ['B', 'F'],
    'F': ['C', 'E', 'G'],
    'G': ['F']
}

def bfs(graph, start, goal=None):
    visited = []
    queue = []

    visited.append(start)
    queue.append(start)

    print("BFS Traversal starting from node:", start)

    while queue:
        node = queue.pop(0)
        print(node, end=" ")

        if goal and node == goal:
            print("\nGoal node '{}' reached!".format(goal))
            return

        for neighbour in graph[node]:
            if neighbour not in visited:
                visited.append(neighbour)
                queue.append(neighbour)

    print("\nTraversal complete.")

# Run BFS from start node 'A'
bfs(graph, 'A')
print()

# Run BFS with a goal state
print("\nBFS with goal state 'G':")
bfs(graph, 'A', goal='G')
