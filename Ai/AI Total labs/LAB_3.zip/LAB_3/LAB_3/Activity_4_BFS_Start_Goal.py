# Activity 4: Changing start and goal states in BFS and observing results

graph = {
    'A': ['B', 'C'],
    'B': ['A', 'D', 'E'],
    'C': ['A', 'F'],
    'D': ['B'],
    'E': ['B', 'F'],
    'F': ['C', 'E', 'G'],
    'G': ['F']
}

def bfs_path(graph, start, goal):
    """BFS that returns the path from start to goal."""
    visited = []
    queue = [[start]]   # queue stores paths, not just nodes

    if start == goal:
        print("Start and Goal are the same node:", start)
        return [start]

    while queue:
        path = queue.pop(0)
        node = path[-1]

        if node not in visited:
            neighbours = graph[node]

            for neighbour in neighbours:
                new_path = list(path)
                new_path.append(neighbour)

                # Goal found
                if neighbour == goal:
                    print("Path found:", " -> ".join(new_path))
                    return new_path

                queue.append(new_path)

            visited.append(node)

    print("No path found from '{}' to '{}'".format(start, goal))
    return None

# Variation 1: A to G
print("=" * 40)
print("Start: A  |  Goal: G")
bfs_path(graph, 'A', 'G')

# Variation 2: D to G
print("\n" + "=" * 40)
print("Start: D  |  Goal: G")
bfs_path(graph, 'D', 'G')

# Variation 3: G to A
print("\n" + "=" * 40)
print("Start: G  |  Goal: A")
bfs_path(graph, 'G', 'A')

# Variation 4: B to F
print("\n" + "=" * 40)
print("Start: B  |  Goal: F")
bfs_path(graph, 'B', 'F')

# Variation 5: Same start and goal
print("\n" + "=" * 40)
print("Start: C  |  Goal: C")
bfs_path(graph, 'C', 'C')
