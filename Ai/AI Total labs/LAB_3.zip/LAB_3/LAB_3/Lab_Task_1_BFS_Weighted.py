# Lab Task 1: BFS on Weighted Graph — Calculate total cost from start to goal

# Weighted graph: each entry is (neighbour, cost)
graph = {
    'A': [('B', 2), ('C', 4)],
    'B': [('A', 2), ('D', 3), ('E', 5)],
    'C': [('A', 4), ('F', 6)],
    'D': [('B', 3)],
    'E': [('B', 5), ('F', 1)],
    'F': [('C', 6), ('E', 1), ('G', 2)],
    'G': [('F', 2)]
}

def bfs_weighted(graph, start, goal):
    """
    BFS on weighted graph.
    Returns shortest (fewest hops) path and its total cost.
    Queue stores: (current_node, path_so_far, total_cost)
    """
    visited = []
    # Each entry: (node, path, cost)
    queue = [(start, [start], 0)]

    print("BFS Weighted Graph  |  Start: {}  |  Goal: {}".format(start, goal))

    while queue:
        node, path, cost = queue.pop(0)

        if node == goal:
            
            print("Path found  :", " -> ".join(path))
            print("Total cost  :", cost)
            return path, cost

        if node not in visited:
            visited.append(node)

            for neighbour, weight in graph[node]:
                if neighbour not in visited:
                    queue.append((neighbour, path + [neighbour], cost + weight))

    print("No path found from '{}' to '{}'.".format(start, goal))
    return None, None

# A to G
print("=" * 45)
bfs_weighted(graph, 'A', 'G')

# Different variations
variations = [('A', 'D'), ('D', 'G'), ('B', 'G'), ('C', 'G')]
for start, goal in variations:
    print("\n" + "=" * 45)
    bfs_weighted(graph, start, goal)
