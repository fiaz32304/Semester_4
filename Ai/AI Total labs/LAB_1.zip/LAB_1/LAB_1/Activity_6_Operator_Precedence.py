# Activity 6: Operator precedence expressions

print("2 + 3 * 6 =", 2 + 3 * 6)                         # * before +
print("(2 + 3) * 6 =", (2 + 3) * 6)                     # brackets first
print("48565878 * 578453 =", 48565878 * 578453)
print("2 + 2 =", 2 + 2)                                  # spaces don't matter
print("(5-1) * ((7+1) / (3-1)) =", (5 - 1) * ((7 + 1) / (3 - 1)))

# Note: '5 +' and '42 + 5 + * 2' are syntax errors in Python
# Uncommenting below lines will cause SyntaxError:
# print(5 +)
# print(42 + 5 + * 2)
