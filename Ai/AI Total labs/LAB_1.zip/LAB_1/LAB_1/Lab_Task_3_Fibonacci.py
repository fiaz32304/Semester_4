# Lab Task 3: Display Fibonacci series up to n terms

n = int(input("Enter number of terms: "))

if n <= 0:
    print("Please enter a positive number.")
elif n == 1:
    print("Fibonacci series:", 0)
else:
    a = 0
    b = 1
    print("Fibonacci series:", end=" ")
    count = 0
    while count < n:
        print(a, end=" ")
        temp = a + b
        a = b
        b = temp
        count += 1
    print()
