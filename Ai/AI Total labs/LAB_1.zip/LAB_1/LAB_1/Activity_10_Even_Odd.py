# Activity 10: Check whether given value is even or odd

num = int(input("Enter an integer: "))

if num % 2 == 0:
    print(num, "is even")
else:
    print(num, "is odd")
