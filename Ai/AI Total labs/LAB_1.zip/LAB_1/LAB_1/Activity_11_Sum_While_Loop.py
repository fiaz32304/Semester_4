# Activity 11: Calculate sum of all values between 0-10 using while loop

total = 0
i = 0

while i <= 10:
    total += i
    i += 1

print("Sum of values from 0 to 10 =", total)
