# Activity 9: Check whether given value is even

num = int(input("Enter an integer: "))

if num % 2 == 0:
    print(num, "is even")
