# Activity 4: Integer division and remainder

# Using // operator for integer division
print("28 // 4 =", 28 // 4)
print("26 // 4 =", 26 // 4)

# Using int() cast operator
print("int(26 / 4) =", int(26 / 4))
print("int(28 / 4) =", int(28 / 4))

# Modulus operator to get remainder
print("28 % 4 =", 28 % 4)   # remainder = 0
print("26 % 4 =", 26 % 4)   # remainder = 2
