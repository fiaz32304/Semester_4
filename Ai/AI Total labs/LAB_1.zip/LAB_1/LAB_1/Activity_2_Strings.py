# Activity 2: Display strings on screen

# Basic string with single quotes
print('hello')

# String with special characters
print('Quote me on this!')

# String with apostrophe using double quotes
print("What's your name?")

# Multi-line string using triple quotes
print('''This is a multi-line string. This is the first line. 
This is the second line.
"What's your name?," I asked. 
He said "Bond, James Bond." ''')
