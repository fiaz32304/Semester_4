# Activity 13: Keep accepting integers until 0 is entered, then display sum

total = 0

while True:
    num = int(input("Enter an integer (0 to stop): "))
    if num == 0:
        break
    total += num

print("Sum of entered values =", total)
