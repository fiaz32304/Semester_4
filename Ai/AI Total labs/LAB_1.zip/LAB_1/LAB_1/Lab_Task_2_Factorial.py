# Lab Task 2: Calculate factorial of a number

num = int(input("Enter a number: "))

if num < 0:
    print("Factorial is not defined for negative numbers.")
elif num == 0:
    print("Factorial of 0 = 1")
else:
    factorial = 1
    i = 1
    while i <= num:
        factorial *= i
        i += 1
    print("Factorial of", num, "=", factorial)
