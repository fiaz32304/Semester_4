# Activity 7: Combine numbers and text

# Text variable
x = "Nancy"
print(x)

# Combine numbers and text using % formatting
s = "My lucky number is %d, what is yours?" % 7
print(s)

# Alternative method using str() and +
s = "My lucky number is " + str(7) + ", what is yours?"
print(s)
