# Activity 5: Calculate powers using ** operator

print("4 ** 3 =", 4 ** 3)
print("4 ** 10 =", 4 ** 10)
print("4 ** 29 =", 4 ** 29)
print("4 ** 150 =", 4 ** 150)
print("4 ** 1000 =", 4 ** 1000)
