# Activity 12: Accept 5 integer values from user and display their sum

total = 0
count = 0

while count < 5:
    num = int(input("Enter integer " + str(count + 1) + ": "))
    total += num
    count += 1

print("Sum of 5 values =", total)
