# Activity 3: Use Python as a calculator

print("2 + 2 =", 2 + 2)
print("50 - 4 =", 50 - 4)
print("23.5 - 2.0 =", 23.5 - 2.0)
print("23 - 18.5 =", 23 - 18.5)
print("5 * 6 =", 5 * 6)
print("2.5 * 10 =", 2.5 * 10)
print("2.5 * 2.5 =", 2.5 * 2.5)
print("28 / 4 =", 28 / 4)   # division returns float
print("26 / 4 =", 26 / 4)
